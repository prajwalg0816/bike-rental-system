

<footer>
  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-md-6">
          <ul>
               <li><a href="admin/">Admin Login</a> </li>
          </ul>
        </div>

        
      </div>
    </div>
  </div>
  
</footer>
